#include<iostream>
using namespace std;

class AudioClip{
  private:
    int channels;
    double resolution,sampleRate;
  public:
    AudioClip(){
      channels=1;
      resolution=8;
      sampleRate=22050;
    }
    double SetResolution(double res){
      if(res==8 || res==16 || res==24){
        resolution=res;
    }
      else{
        cout<<"Resolution not possible"<<endl;
      }

    }
    int SetChannels(int ch){
      if(ch==1 || ch==2){
        channels=ch;
    }
    else{
      cout<<"Channel not possible"<<endl;
    }

    }
    double SetSampleRate(double samRate){
      if(samRate==22050 || samRate==44100 || samRate==88200){
      sampleRate=samRate;
    }
    else{
      cout<<"SampleRate not possible"<<endl;
    }
    }
    double GetResolution(){
      return resolution;
    }
    int GetChannel(){
      return channels;
    }
    double GetSampleRate(){
      return sampleRate;
    }
    bool StudioQuality(){
      if(channels==2 && resolution==24 && sampleRate==88200){
        return true;
      }
      else{
        return false;
      }
    }
    double dataSize(int duration){
      double bytes;
      bytes=channels*duration*(resolution/8)*sampleRate;
      return bytes;
    }

};
int main(int argc, char const *argv[]) {
  AudioClip a1;
  a1.SetResolution(24);
  a1.SetChannels(2);
  a1.SetSampleRate(88200);
  double r=a1.GetResolution();
  cout<<"Resolution="<<r<<endl;
  int c=a1.GetChannel();
  cout<<"Channels="<<c<<endl;
  double s=a1.GetSampleRate();
  cout<<"SampleRate="<<s<<endl;
  bool a=a1.StudioQuality();
  cout<<"StudioQuality acceptable?"<<endl;
  cout<<a<<endl;
  double b=a1.dataSize(25);
  cout<<"Bytes occupied by the AudioClip ="<<b<<endl;
  return 0;
}
